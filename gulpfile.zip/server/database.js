var mongoose = require('mongoose');
//defines  collection name


//defines server/db name
mongoose.connect('mongodb://localhost/developer',function(){
})


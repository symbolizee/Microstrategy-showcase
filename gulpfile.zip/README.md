# react-environemnt-setup
Boilerplate for React + GULP
